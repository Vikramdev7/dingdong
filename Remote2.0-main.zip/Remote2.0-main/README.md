# Remote2.0
Github Action helps you to run build and test programs over Hosted Runners.

i tried to create Simple Repo to Test out Xcode & iOS builds without actual Mac/Hackintosh or any Docker-OSX

-----
Note: Don't even try to misuse, otherwise Github will suspend Account.
-----
